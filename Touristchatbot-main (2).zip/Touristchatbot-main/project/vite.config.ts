import { defineConfig } from 'vite';

export default defineConfig({
  server: {
    host: true, // this will expose the server to the network
  }
  // Your Vite config options
});
