from flask import Flask, request, jsonify, session
from flask_cors import CORS
import pandas as pd
import ollama
from sentence_transformers import SentenceTransformer, util
import torch


app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this to a secure secret key
CORS(app, resources={r"/*": {"origins": ["http://localhost:5173", "http://127.0.0.1:5173", "http://172.30.224.15:5173"]}})


# Load the model
model = SentenceTransformer('paraphrase-MiniLM-L6-v2')

# Load the tourism dataset
df = pd.read_excel('tourist.xlsx')
# Create a combined text field for semantic search
df['search_text'] = df['Location'] + ' ' + df['Category'] + ' ' + df['Details']
df['search_embedding'] = df['search_text'].apply(lambda x: model.encode(x, convert_to_tensor=True))

def find_most_similar_answer(user_question):
    user_question_embedding = model.encode(user_question, convert_to_tensor=True)
    df['similarity'] = df['search_embedding'].apply(lambda x: util.pytorch_cos_sim(user_question_embedding, x).item())
    most_similar_row = df.loc[df['similarity'].idxmax()]
    return most_similar_row['Location'], most_similar_row['Details']

def generate_ollama_response(chat_history, relevant_location, relevant_details):
    prompt = "This is a conversation between a user and a tourism information chat bot.\n"
    for entry in chat_history:
        prompt += f"User: {entry['user']}\nBot: {entry['bot']}\n"

    prompt += (
        f"User: {chat_history[-1]['user']}\n"
        f"Based on the following tourism information for {relevant_location}: \"{relevant_details}\", provide a helpful and informative response about this tourist destination. If the user query is not related to tourism, respond accordingly.\n"
        "Bot:"
    )

    response = ollama.chat(
        model="gpt-oss:120b-cloud",
        messages=[{"role": "user", "content": prompt}]
    )
    return response['message']['content']

@app.route('/')
def index():
    return "welcome to flask backend!"

@app.route('/ask', methods=['POST'])
def send_message():
    data = request.json
    user_message = data['question']
    
    if 'chat_history' not in session:
        session['chat_history'] = []
    
    # Find relevant tourism information from dataset
    relevant_location, relevant_details = find_most_similar_answer(user_message)
    
    # Add to chat history
    session['chat_history'].append({"user": user_message, "bot": None})
    
    # Generate enhanced response
    enhanced_answer = generate_ollama_response(session['chat_history'], relevant_location, relevant_details)
    
    # Update chat history with bot response
    session['chat_history'][-1]['bot'] = enhanced_answer
    
    return jsonify({
        "answer": enhanced_answer,
        "chat_history": session['chat_history']
    })


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
